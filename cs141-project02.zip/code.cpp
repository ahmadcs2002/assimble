//
// Program to simulate coin flips and report % of heads and tails.
//
// Author: Ahmad Alawi, U. of Illinois Chicago, Fall 2020
//

#include <iostream>
#include <fstream>
#include <string>
#include <cctype>  // isspace

using namespace std;

string nextToken(istream& infile);  // defined in "token.cpp"


int readMemory(int&N, string operand, int* memory_A){ // this function will read memory 
    int i;
    i = 0;
    int j = 0;
    int executed;
    executed = 0;
    while (i < N){
        if (operand == "M" +to_string(i)){ // going through the operands and naming the memory
            j =  memory_A[i];
            executed = 1;
        }
        i++;
        
    }
    if (executed == 0){
        j =  stoi(operand);
    }
    return j; // will return the operand "if it is a number will return an integer"
    }
    



void writeMemory(string operand, int value, int&N, int*memory_A) // write data onto memory so I don't have to loop through the code again
{
    int i;
    i = 0;
    int executed;
    executed = 0;
    while (i < N){
        if (operand == "M" +to_string(i)){ // loop through the operands and saving them in the memory
            memory_A[i] = value;
            executed = 1;
            
        }
        i++;
        
    }
    if (executed == 0){
        cout << "**Error in writeMemory: unexpected operand '" << operand << "'" << endl; // throw an error if it won't work
        return;
    }
}
   
void tracer_function(int PC, int ACC, int AR, int CF, string *code_B, string *operand_C, int trace_value){ // this function will print all the tracer updates
  if (trace_value == 1){
      cout << "**Trace: " << "PC=" << PC <<"," << "ACC=" << ACC<< "," <<"AR=" <<AR <<"," << "CF=" <<CF << "," <<code_B[PC] << " "<< operand_C[PC] << endl; // print out the tracers
  }
    
}

void memory_size(int* memory_A, string *code_B, string *operand_C, int& N, int& N_code_B, int& trace_value, string config ){ // it will open the config and take the needed data 
    string type;
    string number;
    ifstream file_(config);
    while (file_ >> type >> number ){  // loop through the config file and get the array sizes
        if (type == "memory:"){
            N = stoi(number); // this way we will have the size of the memory array
        }
        if (type == "code:"){
            N_code_B = stoi(number); // this way we will have the size of the code array
            }
         if (type =="trace:" ){
             trace_value = stoi(number); // this way we will know if the trace is on or off 
             }
     
    }

    file_.close();
    return;
}

int instruction_counter(string *code_B, int N_code_B, int count){ // will count the number of instructions 
    int e = 0;
    
    string compare;
   
    while (e < N_code_B){ // while e is less than the max of code_B
        
        compare = code_B[e];
        

        if (compare != "" ){ // if the instructions is not an empty string
            count +=1; // add one to count for each instruction
        }
        e+=1;
        
    }
    
    return count;
}



int main()
{
   string filename;
   string config;
   cout << "Config file> "; // take the config file 
   cin >> config;// save the config in config
   
    int* memory_A; // will be the memory array
//     int* code_B; // will be the code array
    memory_A = nullptr;
    
    string *operand_C; // will be the operand array
    int N, N_code_B, trace_value;
    operand_C = nullptr; // instializing operand_C
    string *code_B;
    code_B = nullptr; // instializing code_B
    

    memory_size(memory_A, code_B, operand_C, N, N_code_B,trace_value, config ); //caling memory_size
    memory_A = new int[N]; // creating array with size N
    code_B = new string[N_code_B]; // creating array with size N_code_B
    operand_C = new string[N_code_B]; // creating array with size N_code_B
    
    
    int count;
    count = 0; // zero count 
    
    // do the needed prints at the top of the programe
   cout << "Program file> ";
   cin >> filename;
   cout << "**Memory area: " << N << endl;
   cout << "**Code area: " << N_code_B << endl;
   cout << "**Tracing: " << trace_value << endl;
 
   
  
   ifstream infile(filename); 

   if (!infile.good()) // if the file is readable precede if not throw an error
   {
      cout << "**Error: unable to open input file '" << filename << "'." << endl;
   }

  
   string instruction, operand;

   int ACC;
   int CF, PC, AR; // the new required storage for Project2
    // intializing all the storage
    PC = 0;
    ACC = 0;
    CF = 0;
    AR = 0;

   instruction = nextToken(infile);
   int x = 0;
    
    // this while loop will read the file and save all the instructions and operand in their arrays
    
    while (instruction != "")
   {
      if (instruction == "in_i")
      {
         code_B[x] = "in_i";
         x+=1;
         
      }
      else if (instruction == "out_i")
      {
         
          code_B[x] = "out_i";
          x+=1;
 
      }
      else if (instruction == "out_s")
      {
         operand = nextToken(infile);
          code_B[x] = "out_s";
         
          
          operand_C[x] = operand;
          x+=1;
      }
      else if (instruction == "add_i")
      {
         operand = nextToken(infile);
          code_B[x] = "add_i";
          operand_C[x] = operand;
          x+=1;
          
      }
      else if (instruction == "sub_i")
      {
         operand = nextToken(infile);
          code_B[x] = "sub_i";
          operand_C[x] = operand;
          x+=1;
      }
      else if (instruction == "mult_i")
      {
         operand = nextToken(infile);
          code_B[x] = "mult_i";
          operand_C[x] = operand;
          x+=1;
      }
      else if (instruction == "div_i")
      {
         operand = nextToken(infile);
          code_B[x] = "div_i";
          operand_C[x] = operand;
          x+=1;
      }
      else if (instruction == "mod_i")
      {
         operand = nextToken(infile);
         code_B[x] = "mod_i";
          operand_C[x] = operand;
         x+=1;
      }
      else if (instruction == "load_i")
      {
         operand = nextToken(infile);
          code_B[x] = "load_i";
          operand_C[x] = operand;
          x+=1;
      }
      else if (instruction == "store_i")
      {
         operand = nextToken(infile);
          code_B[x] = "store_i";
          operand_C[x] = operand;
          x+=1;
      }
       
       
       else if (instruction == "loada_i"){
          operand = nextToken(infile);
          code_B[x] = "loada_i";
          operand_C[x] = operand;
          x+=1;
       }
       
       else if (instruction == "loadind_i"){
          code_B[x] = "loadind_i";
          x+=1;
       }
       else if (instruction == "storeind_i"){
          code_B[x] = "storeind_i";
          x+=1; 
       }
       
       else if(instruction == "jump"){
          operand = nextToken(infile);
          code_B[x] = "jump";
          operand_C[x] = operand;
          x+=1;
       }
       else if(instruction == "jeq"){
          operand = nextToken(infile);
          code_B[x] = "jeq";
          operand_C[x] = operand;
          x+=1;
       }
       else if(instruction == "jne"){
          operand = nextToken(infile);
          code_B[x] = "jne";
          operand_C[x] = operand;
          x+=1;
       }
       else if(instruction == "jlt"){
          operand = nextToken(infile);
          code_B[x] = "jlt";
          operand_C[x] = operand;
          x+=1;
       }
       else if(instruction == "jle"){
          operand = nextToken(infile);
          code_B[x] = "jle";
          operand_C[x] = operand;
          x+=1;
       }
       else if(instruction == "jgt"){
          operand = nextToken(infile);
          code_B[x] = "jgt";
          operand_C[x] = operand;
          x+=1;
       }
       else if(instruction == "jge"){
          operand = nextToken(infile);
          code_B[x] = "jge";
          operand_C[x] = operand;
          x+=1;
       }
       else if(instruction == "cmp_i"){
          operand = nextToken(infile);
          code_B[x] = "cmp_i";
          operand_C[x] = operand;
          x+=1;
       }
        
      else if (instruction == "clear")
      {
         
          code_B[x] = "clear";
          x+=1;
      }
      else if (instruction == "end")
      {
         
          code_B[x] = "end";
          x+=1;
      }
        instruction = nextToken(infile);
        
}
// printing out the programe size and the word executing as required
    cout << "**Program size: " << instruction_counter(code_B, N_code_B, count) << endl;  
    cout << "**Executing..." <<endl;

    // this loop will read the instructions from the arrays and execute them accordingly
   while (code_B[PC] != "")
   {
      if (code_B[PC] == "in_i")
      {
          tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         cin >> ACC;
         
         PC +=1;
         
      }
      else if (code_B[PC] == "out_i")
      {
          tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         cout << ACC;
         
           PC +=1;
      }
      else if (code_B[PC] == "out_s")
      {
        tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         cout << operand_C[PC];
          
           PC +=1;
          
      }
      else if (code_B[PC] == "add_i")
      {
         tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         ACC = ACC + readMemory(N, operand_C[PC], memory_A);
          
           PC +=1;
         
          
          
      }
      else if (code_B[PC] == "sub_i")
      {
        tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);

         ACC = ACC - readMemory(N, operand_C[PC], memory_A);
          
           PC +=1;
          
      }
      else if (code_B[PC]== "mult_i")
      {
          tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         

         ACC = ACC * readMemory(N, operand_C[PC], memory_A);
          
           PC +=1;
          
      }
      else if (code_B[PC] == "div_i")
      {
          tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         ACC = ACC / readMemory(N, operand_C[PC], memory_A);
          
           PC +=1;
          
      }
      else if (code_B[PC] == "mod_i")
      {
          tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         
         ACC = ACC % readMemory(N, operand_C[PC], memory_A);
          
           PC +=1;
         
      }
      else if (code_B[PC]== "load_i")
      {
           tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         ACC = readMemory(N, operand_C[PC], memory_A);
          
           PC +=1;
          
      }
      else if (code_B[PC] == "store_i")
      {
         tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);

         writeMemory(operand_C[PC], ACC, N, memory_A);
          
           PC +=1;
          
      }
       
       
       else if (code_B[PC]== "loada_i"){
           tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
          AR = readMemory(N, operand_C[PC], memory_A);
           
           PC +=1;
         
       }
       
       else if (code_B[PC]== "loadind_i"){
           tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
           ACC = memory_A[AR];
           
           PC +=1;
        
       }
       else if (code_B[PC] == "storeind_i"){
           tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
           memory_A[AR] = ACC;
           PC +=1;
          
       }
       
       else if (code_B[PC] == "jump"){
           tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
           PC = PC + stoi (operand_C[PC]);  
           
       }
       else if (code_B[PC] == "jeq"){
           if (CF == 0){
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC = PC + stoi(operand_C[PC]);
           }
          
           else{
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC +=1;
           } 
       }
       else if (code_B[PC] == "jne"){
           if (CF !=0){
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC = PC + stoi(operand_C[PC]);
           }
           else{
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC +=1;
           } 
          
       }
       else if (code_B[PC] == "jlt"){
           if (CF < 0){
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC = PC + stoi(operand_C[PC]);
           }
     
          else{
              tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC +=1;
           } 
          
       }
       else if (code_B[PC] == "jle"){
           if(CF<=0){
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC = PC + stoi(operand_C[PC]);
           }
     
           else{
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC +=1;
           } 
          
       }
       else if (code_B[PC] == "jgt"){
           if(CF>0){
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC = PC + stoi(operand_C[PC]);
           }
     
           else{
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC +=1;
           } 
          
       }
       else if (code_B[PC] == "jge"){
           if (CF>=0){
              tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC = PC + stoi(operand_C[PC]);
           }
     
           else{
               tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
               PC +=1;
           } 
          
       }
       else if (code_B[PC]=="cmp_i"){
           tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
           CF = ACC - readMemory(N, operand_C[PC], memory_A);
           
           PC +=1;
       }
      else if (code_B[PC]== "clear") // instialize all the memory
      {
         int h = 0;
          tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
          
          while (h<N){
              
               memory_A[h] = 0;
              
              h = h+1;
             
          }
          ACC = 0;
          AR = 0;
          CF = 0;
          
        
         
           PC +=1;

      }
      else if (code_B[PC]== "end") // end the programe
      {
         tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         break;
           PC +=1;

      }
       
      else
      {
          tracer_function( PC, ACC,  AR,  CF, code_B, operand_C, trace_value);
         cout << "**Error: unknown instruction '" << instruction << "'." << endl;
      }
    
   } 
       
//       instruction = nextToken(infile);
//    }

   //
   // done
   //
    
    // delete all the arrays to avoid memory leack
    delete []memory_A;
    delete []operand_C;
    delete []code_B;
   return 0;
}


//
// nextToken
//
// Returns the next token in the input stream; returns the empty
// string "" if there is no more input (i.e. end of stream).
// Comments (i.e. REM ...) are discarded by this function, and 
// never returned.
//

string nextToken(istream& stream) {
   char  c;
   string token = "";

   while (token == "")
   {
      // skip initial whitespace:
      stream.get(c);
      while (!stream.eof() && isspace(c))
      {
         stream.get(c);
      }

      // did we reach end of file?  If so, there's no token:
      if (stream.eof())
      {
         return "";
      }

      if (c == '"')  // a string literal, loop until end of string:
      {
         stream.get(c);
         while (!stream.eof() && c != '"')
         {
            if (c == '\\')  // escape char?  Then read next done
            {
               stream.get(c);

               if (c == 'n')
                  c = '\n';
               else if (c == 't')
                  c = '\t';
               else if (c == 'f')
                  c = '\f';
               else if (c == 'r')
                  c = '\r';
               else
                  token += '\\';  // not sure what it is, so leave alone:
            }

            token += c;
            stream.get(c);
         }
      }
      else  // we have a word or numeric literal:
      {
         token += c;  // append that first char

         // now append remaining chars up until next whitespace:
         stream.get(c);
         while (!stream.eof() && !isspace(c))
         {
            token += c;
            stream.get(c);
         }
      }

      //
      // was the token REM?  If so, this denotes a comment, so discard 
      // rest of line and try again:
      //
      if (token == "REM")
      {
         //
         // we want to discard the rest of the line, except when
         // REM already comes at the end of the line (in which case
         // we do nothing):
         //
         if (c == '\n' || c == '\r')  // REM @ end of line, do nothing
         {
            // nothing
         }
         else
         {
            getline(stream, token);  // discard rest of line:
         }

         token = "";  // try again:
      }
   }//while

   //
   // done, we have a token to return:
   //
   return token;
}
